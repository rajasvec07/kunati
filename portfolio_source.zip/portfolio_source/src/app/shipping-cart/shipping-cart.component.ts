import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipping-cart',
  templateUrl: './shipping-cart.component.html',
  styleUrls: ['./shipping-cart.component.scss']
})
export class ShippingCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

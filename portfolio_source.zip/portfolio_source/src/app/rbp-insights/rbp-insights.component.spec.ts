import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RbpInsightsComponent } from './rbp-insights.component';

describe('RbpInsightsComponent', () => {
  let component: RbpInsightsComponent;
  let fixture: ComponentFixture<RbpInsightsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RbpInsightsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RbpInsightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rbp-insights',
  templateUrl: './rbp-insights.component.html',
  styleUrls: ['./rbp-insights.component.scss']
})
export class RbpInsightsComponent implements OnInit {
  indexDropdown: Object[];
  selectedIndexValue: String = "";
  constructor() { 
    this.indexDropdown = [
      {
        "text":"Dynamic Asset Allocation",
        "tagLine":"Directional Allocation Indexes",
        "subNav": [
          {
            "text":"Large-Cap",
            "tagLine":""
          },
          {
            "text":"SMID-Cap",
            "tagLine":""
          }
        ]
      },
      {
        "text":"Higher Beta, Market Beta, Lower Beta",
        "tagLine":"Directional Indexes",
        "subNav": [
          {
            "text":"Large-Cap Aggresive",
            "tagLine":""
          },
          {
            "text":"Large-Cap Market",
            "tagLine":""
          },
          {
            "text":"Large-Cap Defensive",
            "tagLine":""
          },
          {
            "text":"SMID-Cap Aggresive",
            "tagLine":""
          },
          {
            "text":"SMID-Cap Market",
            "tagLine":""
          },
          {
            "text":"SMID-Cap Defensive",
            "tagLine":""
          }
        ]
      },
      {
        "text":"Value",
        "tagLine":"Style Indexes"
      },
      {
        "text":"Dividend Income",
        "tagLine":"Dividend Indexes"
      },
      {
        "text":"Small-Cap Core",
        "tagLine":"Small Cap Indexes"
      },
      {
        "text":"Islamic Shari'ah",
        "tagLine":"Islamic Market Indexes"
      },
      {
        "text":"Low Volatility",
        "tagLine":"Blended Indexes"
      }
    ]
  }

  ngOnInit() {
  }

  setSelectedindexValue(event)
  {
    let e = window.event || event;
    e.stopPropagation();
    console.log(e.target.title);
    this.selectedIndexValue = e.target.title;
  }

}

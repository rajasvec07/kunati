import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShippingCartComponent } from './shipping-cart/shipping-cart.component';
import { RbpInsightsComponent } from './rbp-insights/rbp-insights.component';


const routes: Routes = [
  {
    path: 'shopping',
    component: ShippingCartComponent,
    pathMatch: 'full'
  },
  {
    path: '**',
    component: RbpInsightsComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
